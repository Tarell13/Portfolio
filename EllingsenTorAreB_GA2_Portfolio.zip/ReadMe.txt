Link to video of gameplay:
https://youtu.be/UHoVHZzZ5WU 

Content of ZIP:
Bee-Cause - Built game
GDD - GameDesignDocument	(2nd.draft)
TDD - TechnicalDesignDocument	(3rd.draft)
ReadMe - Information